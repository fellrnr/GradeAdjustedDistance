﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GradeAdjustedDistance
{
    public class Options
    {
        private Options() //TODO: persist config and allow editing
        {
        }
        static Options() { }
        public static Options Instance { get; set; } = new Options();


        //Default formula - //=POWER(A2,2)*15.14+A2*2.896+1.0098

        [Description("Multiplier for X squared where X is the slope")]
        public double GradeAdjustmentX2 { get; set; } = 15.14;

        [Description("Multiplier for X where X is the slope")]
        public double GradeAdjustmentX { get; set; } = 2.896;

        [Description("Offset for grade adjustment")]
        public double GradeAdjustmentOffset { get; set; } = 1.0098;

        [Description("Min slope (GPX can have noise that creates silly slopes)")]
        public double MinSlope { get; set; } = -0.5;

        [Description("Max slope (GPX can have noise that creates silly slopes)")]
        public double MaxSlope { get; set; } = 0.5;

        [Description("Show line for cost adjustment")]
        public bool ShowCost { get; set; } = false;

        [Description("Show line for raw elevation changes")]
        public bool ShowRawElevationChanges { get; set; } = false;

        [Description("Show line for smoothed elevation changes")]
        public bool ShowSmoothedElevationChanges { get; set; } = false;

        [Description("Show line for calculated slope")]
        public bool ShowSlope { get; set; } = false;

        public enum Smoothing { AverageWindow, SimpleExponential };

        [Description("How to do the elevation smoothing")]
        public Smoothing SmoothingType { get; set; } = Smoothing.SimpleExponential;

        [Description("How big should the smoothing window be (in meters)")]
        public int SmoothingWindow { get; set; } = 50;
    }
}
