using Gpx;
using ScottPlot;
using ScottPlot.Renderable;

namespace GradeAdjustedDistance
{
    public partial class GradeAdjustedDistance : Form
    {
        public GradeAdjustedDistance()
        {
            InitializeComponent();
        }

        private void openGPXToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                //openFileDialog.InitialDirectory = "c:\\";
                openFileDialog.Filter = "GPX|*.gpx|All files (*.*)|*.*";
                openFileDialog.FilterIndex = 1;
                //openFileDialog.RestoreDirectory = true;
                openFileDialog.ReadOnlyChecked = true;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    totalGradeAdjustedDistance = 0;
                    totalDistance = 0;
                    totalAscent = 0;
                    totalGradeAdjustedDistance = 0;
                    costChart = new List<double>();
                    slopeChart = new List<double>();
                    cumulativeDistance = new List<double>();
                    distancesBetween = new List<double>();
                    altitudeChart = new List<double>();
                    rawElevationChanges = new List<double>();

                    //Get the path of specified file
                    var filePath = openFileDialog.FileName;
                    ProcessGPX(openFileDialog.OpenFile());
                }
            }

        }

        private void ProcessGPX(Stream input)
        {
            using (GpxReader reader = new GpxReader(input))
            {
                while (reader.Read())
                {
                    switch (reader.ObjectType)
                    {
                        case GpxObjectType.Metadata:
                            
                            break;
                        case GpxObjectType.WayPoint:
                            
                            break;
                        case GpxObjectType.Route:
                            GpxRoute gpxRoute = reader.Route;
                            ProcessRoute(gpxRoute);
                            break;
                        case GpxObjectType.Track:
                            GpxTrack gpxTrack = reader.Track;
                            ProcessRoute(gpxTrack);

                            break;
                    }
                }
            }
        }

        private void ProcessRoute(GpxTrack gpxTrack)
        {
            GpxPointCollection<GpxPoint> gpxPoints = new GpxPointCollection<GpxPoint>();

            foreach (GpxTrackSegment segment in gpxTrack.Segments)
            {
                GpxPointCollection<GpxPoint> segmentPoints = segment.TrackPoints.ToGpxPoints();

                foreach (GpxPoint point in segmentPoints)
                {
                    gpxPoints.Add(point);
                }
            }

            ProcessRoute(gpxPoints);
        }

        private void ProcessRoute(GpxRoute gpxRoute)
        {
            GpxPointCollection<GpxPoint> gpxPoints = gpxRoute.ToGpxPoints();

            ProcessRoute(gpxPoints);
        }
        private void ProcessRoute(GpxPointCollection<GpxPoint> gpxPoints)
        {
            //GpxPointCollection<GpxRoutePoint> gpxRoutePoints = gpxRoute.RoutePoints;


            GpxPoint? lastPoint = null;
            List<double> cumulativeDistanceTmp = new List<double>();
            List<double> altitudeChartTmp = new List<double>();
            double totalDistanceTmp = 0;
            foreach (GpxPoint gpxPoint in gpxPoints)
            {
                if(lastPoint != null && gpxPoint.Elevation != null && lastPoint.Elevation != null)
                {
                    double distanceBetween = gpxPoint.GetDistanceFrom(lastPoint) * 1000; //Km to meters
                    double elevationChange = (double)gpxPoint.Elevation - (double)lastPoint.Elevation;
                    totalDistanceTmp += distanceBetween;
                    cumulativeDistanceTmp.Add(totalDistanceTmp);
                    altitudeChartTmp.Add((double)gpxPoint.Elevation);
                }
                lastPoint = gpxPoint;
            }

            Tuple<List<double>, List<double>> interpolatedLists = Smoothing.Interpolate(cumulativeDistanceTmp, altitudeChartTmp);
            cumulativeDistance = interpolatedLists.Item1;
            altitudeChart= interpolatedLists.Item2;

            double lastAltitude = altitudeChart.First();
            double lastDistance = cumulativeDistance.First();
            for (int i = 0; i < cumulativeDistance.Count; i++)
            {
                double elevationChange = altitudeChart[i] - lastAltitude;
                lastAltitude = altitudeChart[i];
                rawElevationChanges.Add(elevationChange);

                double distanceChange = cumulativeDistance[i] - lastDistance;
                lastDistance = cumulativeDistance[i];
                distancesBetween.Add(distanceChange);
            }

            ProcessRoute();
        }


        double totalGradeAdjustedDistance = 0;
        double totalDistance = 0;
        double totalAscent = 0;
        double totalElevation = 0;
        List<double> costChart = new List<double>();
        List<double> slopeChart = new List<double>();
        List<double> cumulativeDistance = new List<double>();
        List<double> distancesBetween = new List<double>();
        List<double> altitudeChart = new List<double>();
        List<double> rawElevationChanges = new List<double>();
        private List<Axis> CurrentAxis { get; set; } = new List<Axis>();

        private void ProcessRoute()
        {
            cumulativeDistance.Clear();
            costChart.Clear();
            slopeChart.Clear();
            totalGradeAdjustedDistance = 0;
            totalDistance = 0;
            totalAscent = 0;
            totalElevation = 0;

            double[] smoothedElevationChanges;
            if (Options.Instance.SmoothingType == Options.Smoothing.AverageWindow)
                smoothedElevationChanges = Smoothing.WindowSmoothed(rawElevationChanges.ToArray(), Options.Instance.SmoothingWindow);
            else
                smoothedElevationChanges = Smoothing.SimpleExponentialSmoothed(rawElevationChanges.ToArray(), Options.Instance.SmoothingWindow);

            for (int i = 0; i < distancesBetween.Count; i++)
            {
                double distanceBetween = distancesBetween[i];
                double elevationChange = smoothedElevationChanges[i];
                if (distanceBetween > 0)
                {

                    double slope = elevationChange / distanceBetween;

                    //constrain slope
                    if (slope > Options.Instance.MaxSlope)
                        slope = Options.Instance.MaxSlope;

                    if (slope < Options.Instance.MinSlope)
                        slope = Options.Instance.MinSlope;

                    //=POWER(A2,2)*15.14+A2*2.896+1.0098
                    //double cost = Math.Pow(slope, 2) * 15.14 + slope * 2.896 + 1.0098;
                    double cost = Math.Pow(slope, 2) * Options.Instance.GradeAdjustmentX2 + slope * Options.Instance.GradeAdjustmentX + Options.Instance.GradeAdjustmentOffset;
                    double gradeAdjustedDistance = distanceBetween * cost;
                    totalGradeAdjustedDistance += gradeAdjustedDistance;
                    totalDistance += distanceBetween;
                    totalElevation += elevationChange;
                    if (elevationChange > 0) { totalAscent += elevationChange; }
                    costChart.Add(cost);
                    slopeChart.Add(slope);
                    cumulativeDistance.Add(totalDistance);
                }
                else
                {
                    costChart.Add(1);
                    slopeChart.Add(0);
                    cumulativeDistance.Add(totalDistance);
                }
            }
            UpdateGraphs(smoothedElevationChanges);
        }
        public void UpdateGraphs(double[] smoothedElevationChanges)
        {
            formsPlot1.Plot.Clear();
            foreach (Axis axis in CurrentAxis) { formsPlot1.Plot.RemoveAxis(axis); }
            CurrentAxis.Clear();

            string label = string.Format("Distance {0:N} Km, Grade Adjusted Distance {1:N} Km, total ascent {2:N}m, net elevation {3:N}m", totalDistance / 1000, totalGradeAdjustedDistance / 1000, totalAscent, totalElevation);
            //toolStripTextBox1.Text = label;
            formsPlot1.Plot.XAxis2.Label(label);
            var elevationGraph = formsPlot1.Plot.AddScatter(cumulativeDistance.ToArray(), altitudeChart.ToArray());
            formsPlot1.Plot.YAxis.Label("Elevation");
            formsPlot1.Plot.YAxis.Color(elevationGraph.Color);
            elevationGraph.YAxisIndex = 0;

            Axis yAxis;
            int arrayIndex = 1;

            if (Options.Instance.ShowCost)
            {
                var costGraph = formsPlot1.Plot.AddScatter(cumulativeDistance.ToArray(), costChart.ToArray());
                yAxis = formsPlot1.Plot.AddAxis(ScottPlot.Renderable.Edge.Left);
                if (yAxis != null)
                {
                    yAxis.AxisIndex = arrayIndex++;
                    yAxis.Color(costGraph.Color);
                    costGraph.YAxisIndex = yAxis.AxisIndex;
                    yAxis.Label("Cost");
                    CurrentAxis.Add(yAxis);
                }
            }

            if (Options.Instance.ShowSmoothedElevationChanges)
            {
                var elevationChangesGraph = formsPlot1.Plot.AddScatter(cumulativeDistance.ToArray(), smoothedElevationChanges);
                yAxis = formsPlot1.Plot.AddAxis(ScottPlot.Renderable.Edge.Left);
                if (yAxis != null)
                {
                    yAxis.AxisIndex = arrayIndex++;
                    yAxis.Color(elevationChangesGraph.Color);
                    elevationChangesGraph.YAxisIndex = yAxis.AxisIndex;
                    yAxis.Label("Elevation Change");
                    CurrentAxis.Add(yAxis);
                }

            }

            if (Options.Instance.ShowSlope)
            {
                var slopeGraph = formsPlot1.Plot.AddScatter(cumulativeDistance.ToArray(), slopeChart.ToArray());
                yAxis = formsPlot1.Plot.AddAxis(ScottPlot.Renderable.Edge.Left);
                if (yAxis != null)
                {
                    yAxis.AxisIndex = arrayIndex++;
                    yAxis.Color(slopeGraph.Color);
                    slopeGraph.YAxisIndex = yAxis.AxisIndex;
                    yAxis.Label("slope");
                    CurrentAxis.Add(yAxis);
                }
            }

            if (Options.Instance.ShowRawElevationChanges)
            {
                var rawElevationChangesGraph = formsPlot1.Plot.AddScatter(cumulativeDistance.ToArray(), rawElevationChanges.ToArray());
                yAxis = formsPlot1.Plot.AddAxis(ScottPlot.Renderable.Edge.Left);
                if (yAxis != null)
                {
                    yAxis.AxisIndex = arrayIndex++;
                    yAxis.Color(rawElevationChangesGraph.Color);
                    rawElevationChangesGraph.YAxisIndex = yAxis.AxisIndex;
                    yAxis.Label("Raw Elevation Changes");
                    CurrentAxis.Add(yAxis);
                }
            }

            formsPlot1.Refresh();

        }


        public static double DistanceTo(double lat1, double lon1, double lat2, double lon2, char unit = 'K')
        {
            double rlat1 = Math.PI * lat1 / 180;
            double rlat2 = Math.PI * lat2 / 180;
            double theta = lon1 - lon2;
            double rtheta = Math.PI * theta / 180;
            double dist =
                Math.Sin(rlat1) * Math.Sin(rlat2) + Math.Cos(rlat1) *
                Math.Cos(rlat2) * Math.Cos(rtheta);
            dist = Math.Acos(dist);
            dist = dist * 180 / Math.PI;
            dist = dist * 60 * 1.1515;

            switch (unit)
            {
                case 'K': //Kilometers -> default
                    return dist * 1.609344;
                case 'N': //Nautical Miles 
                    return dist * 0.8684;
                case 'M': //Miles
                    return dist;
            }

            return dist;
        }
        

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void toolStripTextBox1_Click(object sender, EventArgs e)
        {

        }

        private void optionsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OptionsForm1 optionsForm = new OptionsForm1();
            optionsForm.ShowDialog();
            if (cumulativeDistance.Count > 0)
                ProcessRoute();
        }
    }
}